from django.shortcuts import render
# hide warnings
import warnings
warnings.filterwarnings('ignore')

def index(request):
    return render(request, 'polls/menue.html', {})