"""mysite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import include,path
from django.urls import path
from . import viewsy
from polls import views

urlpatterns = [
    path('polls/', include('polls.urls')),
]

urlpatterns = [
    path('', viewsy.index, name='index'),
    path('analyse1', views.index, name='index'),
    path('analyse2', views.index2, name='index2'),
    path('analyse3', views.index3, name='index3'),
    path('analyse4', views.index4, name='index4'),
    path('analyse5', views.index5, name='index5'),
    path('resultat1', views.index6,name ='index6'),
    path('resultat1', views.index6,name ='index6'),
    path('resultat2', views.index7,name ='index7'),
    path('resultat3', views.index8,name ='index8'),
    path('resultat4', views.index9,name ='index9'),
    path('resultat5', views.index10,name ='index10'),
]
