from django.urls import path
from . import views

urlpatterns = [
    path('analyse1', views.index, name='index'),
    path('analyse2', views.index2, name='index2'),
    path('analyse3', views.index3, name='index3'),
    path('analyse4', views.index4, name='index4'),
    path('analyse5', views.index5, name='index5'),
    path('resultat1', views.index6,name ='index6'),
    path('resultat2', views.index7,name ='index7'),
    path('resultat2', views.index8,name ='index8'),
    path('resultat2', views.index9,name ='index9'),
    path('resultat2', views.index10,name ='index10'),
]
