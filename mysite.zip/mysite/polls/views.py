from django.shortcuts import render
from django.http import HttpResponse

#Basic Libraries
import pandas as pd
import numpy as np
#Plotting and Visualization
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objs as go
import plotly.figure_factory as ff
import folium
from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits import mplot3d

#Requests and BeautifulSoup
import re
import requests
from bs4 import BeautifulSoup

#Scickit Learn and machine learning features
import sklearn
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder

from sklearn import decomposition
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import mean_squared_error
from sklearn.cluster import KMeans
from sklearn.datasets import make_classification
from sklearn.decomposition import PCA
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.naive_bayes import BernoulliNB
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import BaggingClassifier
from sklearn.svm import SVC
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.ensemble import ExtraTreesClassifier
from sklearn import svm
from sklearn import svm, datasets
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import RandomizedSearchCV

from xgboost import XGBClassifier
from sklearn.metrics import mean_absolute_percentage_error
from sklearn.metrics import accuracy_score
# Hide Warning Messages
import warnings
warnings.filterwarnings('ignore')

full_table_non_triee = pd.read_csv('https://archive.ics.uci.edu/ml/machine-learning-databases/00254/biodeg.csv', sep = ';', header=None)
#Naming columns
columns_name=["SpMax_L",
              "J_Dz(e)",
              "nHM",
              "F01[N-N]",
              "F04[C-N]",
              "NssssC",
              "nCb-",
              "C%",
              "nCp",
              "nO",
              "F03[C-N]",
              "SdssC",
              "HyWi_B(m)",
              "LOC",
              "SM6_L",
              "F03[C-O]",
              "Me",
              "Mi",
              "nN-N",
              "nArNO2",
              "nCRX3",
              "SpPosA_B(p)",
              "nCIR",
              "B01[C-Br]",
              "B03[C-Cl]",
              "N-073",
              "SpMax_A",
              "Psi_i_1d",
              "B04[C-Br]",
              "SdO",
              "TI2_L",
              "nCrt",
              "C-026",
              "F02[C-N]",
              "nHDon",
              "SpMax_B(m)",
              "Psi_i_A",
              "nN",
              "SM6_B(m)",
              "nArCOOR",
              "nX",
              "experimental class"]
full_table_non_triee.columns=columns_name
#DataFrame Preprocessed
df = full_table_non_triee
label_liste = {'RB':1,'NRB':0}
df['experimental class'] = df['experimental class'].map(label_liste)


# %%
def index(request):
    return render(request, "polls/index.html", {})

def index2(request):
    return render(request, "polls/index2.html", {})

def index3(request):
    return render(request, "polls/index3.html", {})

def index4(request):
    return render(request, "polls/index4.html", {})

def index5(request):
    return render(request, "polls/index5.html", {})

def index6(request):
    
    f = plt.figure()
    df.iloc[:,:].plot(kind = 'area', stacked = False, figsize = (30,10))
    plt.title("Plotting of all the variables", fontsize='x-large', fontweight = 'bold')
    plt.xlabel("Feature", fontsize='x-large', fontstyle = "italic")
    plt.ylim(-10,70)
    
    canvas = FigureCanvasAgg(f)    
    response = HttpResponse(content_type='image/png')
    canvas.print_png(response)
    matplotlib.pyplot.close(f)   
    return response

def index7(request):

    #Calculation of the importance of variables in order to plot the most important for the rest of the study
    #Separation of the target and the rest of the data
    x = df.drop('experimental class', axis=1)
    y = df['experimental class']
    #Training set and test set
    x_train, x_test, y_train, y_test = train_test_split(x, y)
    # Define the model
    model = LogisticRegression()
    # Fit the model
    model.fit(x_train, y_train)
    # Get importance
    importance = model.coef_[0]
    # Summarize feature importance/contribution
    importancedf = pd.DataFrame(importance)
    importancedf.columns = ['Importance']
    importancedf = abs(importancedf)
    importancedf = importancedf.sort_values(by = 'Importance', ascending = False).style.background_gradient(cmap='Greens').set_caption('Molecular Descriptors sorted by contribution to the model')
    # Plot features importance
    values = [x for x in range(len(importance))]
    axis = sns.barplot(values,abs(importance),palette = 'icefire')
    plt.title("Variables importance to the model", fontsize='x-large', fontweight = 'bold')
    plt.xlabel("Molecular Descriptor", fontsize='x-large', fontstyle = "italic")
    plt.ylabel("Importance", fontsize='x-large', fontstyle = "italic")
    properties1 = {"rotation" : 90, "color":"blue", "fontsize":"smaller"}
    plt.setp(axis.get_xticklabels(), **properties1)
    properties2 = {"rotation" : 0, "color":"red", "fontsize":"smaller"}
    plt.setp(axis.get_yticklabels(), **properties2)

    f = plt.figure()
    canvas = FigureCanvasAgg(f)    
    response = HttpResponse(content_type='image/png')
    canvas.print_png(response)
    matplotlib.pyplot.close(f)   
    return response

def index8(request):
       
    chemical1 = request.POST.get('chemical1')
    chemical2 = request.POST.get('chemical2')
    
    f = plt.figure()
    df[[chemical1,chemical2]].plot.scatter(chemical1,chemical2, figsize = (10,10), color = 'green')
    plt.title(f"{chemical2} in function of {chemical1}", fontsize='x-large', fontweight = 'bold')
    plt.xlabel(chemical1, fontsize='x-large', fontstyle = "italic")
    plt.ylabel(chemical2, fontsize='x-large', fontstyle = "italic")
    plt.xticks(**{"rotation" : 0, "color":"blue", "fontsize":"large"})
    plt.yticks(**{"rotation" : 0, "color":"blue", "fontsize":"large"})
    
    canvas = FigureCanvasAgg(f)    
    response = HttpResponse(content_type='image/png')
    canvas.print_png(response)
    matplotlib.pyplot.close(f)   
    return response

def index9(request):
       
    chemical1 = request.POST.get('chemical1')
    
    f = plt.figure()
    df[[chemical1,'experimental class']].plot.scatter(chemical1,'experimental class', figsize = (10,10), color = 'green')
    plt.title(f"experimental class in function of {chemical1}", fontsize='x-large', fontweight = 'bold')
    plt.xlabel(chemical1, fontsize='x-large', fontstyle = "italic")
    plt.ylabel('experimental class', fontsize='x-large', fontstyle = "italic")
    plt.xticks(**{"rotation" : 0, "color":"blue", "fontsize":"large"})
    plt.yticks(**{"rotation" : 0, "color":"blue", "fontsize":"large"})
    
    canvas = FigureCanvasAgg(f)    
    response = HttpResponse(content_type='image/png')
    canvas.print_png(response)
    matplotlib.pyplot.close(f)   
    return response

def index10(request):
       
    col_quanti = ["SpMax_L","J_Dz(e)","nHM","F01[N-N]","F04[C-N]","NssssC","nCb-","C%","nCp","nO","F03[C-N]","SdssC","HyWi_B(m)","LOC","SM6_L","F03[C-O]",
              "Me","Mi","nN-N","nArNO2","nCRX3","SpPosA_B(p)","nCIR","B01[C-Br]","B03[C-Cl]","N-073","SpMax_A","Psi_i_1d","B04[C-Br]","SdO","TI2_L",
              "nCrt","C-026","F02[C-N]","nHDon","SpMax_B(m)","Psi_i_A","nN","SM6_B(m)","nArCOOR","nX"]
    transfo_quanti = Pipeline(steps=[
    ('imputation', SimpleImputer(strategy='median'))#,
    #('standard', StandardScaler())
    ])


    preparation = ColumnTransformer(
        transformers=[
            ('quanti', transfo_quanti , col_quanti)])

    df_transfo = preparation.fit_transform(df)

    # we separate the target from the rest of the data
    x = df.drop('experimental class', axis=1)
    y = df['experimental class']

    # we build the training and validation samples
    x_train, x_test, y_train, y_test = train_test_split(x, y)

    tabResult_classification= []

    modele_ml = Pipeline(steps=[('preparation', preparation),
                        ('logit', LogisticRegression(solver='lbfgs'))])
    modele_ml.fit(x_train, y_train)
    y_pred=modele_ml.predict(x_test)
    #res=modele_ml.score(x_test, y_test)
    res=accuracy_score(y_test,y_pred)
    tabResult_classification.append(["LogisticRegression",res])
    #===================================================
    modele_ml2 = Pipeline(steps=[('preparation', preparation),
                        ('logit', RandomForestClassifier())])
    modele_ml2.fit(x_train, y_train)
    y_pred2=modele_ml2.predict(x_test)
    res2=accuracy_score(y_test,y_pred2)
    tabResult_classification.append(["RandomForestClassifier",res2])
    #===================================================
    modele_ml3 = Pipeline(steps=[('preparation', preparation),
                        ('logit', XGBClassifier())])
    modele_ml3.fit(x_train, y_train)
    y_pred3=modele_ml3.predict(x_test)
    res3=accuracy_score(y_test,y_pred3)
    tabResult_classification.append(["XGBClassifier",res3])
    #===================================================
    modele_ml4 = Pipeline(steps=[('preparation', preparation),
                        ('logit', AdaBoostClassifier())])
    modele_ml4.fit(x_train, y_train)
    y_pred4=modele_ml4.predict(x_test)
    res4=accuracy_score(y_test,y_pred4)  
    tabResult_classification.append(["AdaBoostClassifier",res4])
    #===================================================
    modele_ml5 = Pipeline(steps=[('preparation', preparation),
                         ('logit', GradientBoostingClassifier())])
    modele_ml5.fit(x_train, y_train)
    y_pred5=modele_ml5.predict(x_test)
    res5=accuracy_score(y_test,y_pred5)  
    tabResult_classification.append(["GradientBoostingClassifier",res5])
    #===================================================
    modele_ml6 = Pipeline(steps=[('preparation', preparation),
                          ('logit', HistGradientBoostingClassifier())])
    modele_ml6.fit(x_train, y_train)
    y_pred6=modele_ml6.predict(x_test)
    res6=accuracy_score(y_test,y_pred6)  
    tabResult_classification.append(["HistGradientBoostingClassifier",res6]) 
    #===================================================
    modele_ml7 = Pipeline(steps=[('preparation', preparation),
                          ('logit', ExtraTreesClassifier())])
    modele_ml7.fit(x_train, y_train)
    y_pred7=modele_ml7.predict(x_test)
    res7=accuracy_score(y_test,y_pred7)
    tabResult_classification.append(["ExtraTreesClassifier",res7])   
    #===================================================
    modele_ml8 = Pipeline(steps=[('preparation', preparation),
                        ('logit', BaggingClassifier(base_estimator=SVC()))])
    modele_ml8.fit(x_train, y_train)
    y_pred8=modele_ml8.predict(x_test)
    res8=accuracy_score(y_test,y_pred8)
    tabResult_classification.append(["BaggingClassifier",res8])   
    #===================================================
    modele_ml9 = Pipeline(steps=[('preparation', preparation),
                          ('logit', BernoulliNB())])
    modele_ml9.fit(x_train, y_train)
    y_pred9=modele_ml9.predict(x_test)
    res9=accuracy_score(y_test,y_pred9)
    tabResult_classification.append(["BernoulliNB",res9])  
    #===================================================
    modele_ml10 = Pipeline(steps=[('preparation', preparation),
                        ('logit', MLPClassifier())])
    modele_ml10.fit(x_train, y_train)
    y_pred10=modele_ml10.predict(x_test)
    res10=accuracy_score(y_test,y_pred10)
    tabResult_classification.append(["MLPClassifier",res10])

    #Putting the informations of the Accuracy in a DataFrame to make it more visual and see which is the best model
    dfResult_classification = pd.DataFrame(tabResult_classification,columns=('Model','Accuracy'))
    dfResult_classification = dfResult_classification.sort_values(by="Accuracy",ascending=False,ignore_index=True).style.background_gradient(cmap='Blues').set_caption('Summary of Models experimented and their Accuracy')

    dfResult_classification = dfResult_classification.data

    f = plt.figure()
    axis = sns.barplot(dfResult_classification['Model'],dfResult_classification['Accuracy'],palette = 'Set1',edgecolor = 'k')
    plt.title("Accuracy per Model", fontsize='x-large', fontweight = 'bold')
    plt.xlabel("Model", fontsize='x-large', fontstyle = "italic")
    plt.ylabel("Accuracy", fontsize='x-large', fontstyle = "italic")
    properties1 = {"rotation" : 90, "color":"blue", "fontsize":"smaller"}
    plt.setp(axis.get_xticklabels(), **properties1)
    properties2 = {"rotation" : 0, "color":"red", "fontsize":"smaller"}
    plt.setp(axis.get_yticklabels(), **properties2)
    plt.ylim(min(dfResult_classification['Accuracy'])-0.01,max(dfResult_classification['Accuracy'])+0.01)

    canvas = FigureCanvasAgg(f)    
    response = HttpResponse(content_type='image/png')
    canvas.print_png(response)
    matplotlib.pyplot.close(f)   
    return response