import cgi
import cgitb

cgitb.enable()
form = cgi.FieldStorage()

chemical1=form.getvalue("chemical1")
chemical2=form.getvalue("chemical2")

print("Content-type: text/html; charset=utf-8\n")

html = """<!DOCTYPE html>
<head>
    <meta charset="utf-8"
    <title>chemical 2 in function of chemical 1</title>
<head>
<body>
    <h1>Results</h1>
"""
print(html)

print(f"Hello {chemical1} and {chemical2} !")

html="""        
    <form method="post" action="forms.py" target="_blank">{% csrf_token %}
        <p><input type="text" name="chemical1">
        <input type="submit" value="Envoyer"></p>
    </form>
    <form method="post" action="forms.py" target="_blank">{% csrf_token %}
        <p><input type="text" name="chemical2">
        <input type="submit" value="Envoyer"></p>
    </form>
</body>
</html>
"""

print(html)